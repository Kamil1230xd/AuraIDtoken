# Aura-IDToken — Landing (Thirdweb-style)

This is a lightweight static landing page for **Aura-IDToken**. It is designed to be developer-first and visually similar to modern Web3 platforms.

## What's included
- `index.html` — landing page
- `style.css` — styling (dark, futuristic)
- `app.js` — small client interactions (API check)
- `assets/logo.svg` — brand svg
- `assets/glow.mp4` — placeholder video (replace with real loop)
- `README.md` — this file

## How to deploy to Render.com (Static Site)
1. Create or use a GitHub repository (e.g. `Kamil1230xd/aura-idtoken`).
2. Commit and push the contents of this folder to `main` branch.
3. On Render.com click **New -> Static Site** and link to the GitHub repo.
4. Set the build command to (leave empty) and the publish directory to `/`.
5. Click **Create Static Site**. Render will provide HTTPS automatically.

## Quick local preview
Open `index.html` in a browser (works offline). To preview dynamic API check, host with a simple server:
```bash
python -m http.server 8000
# then open http://localhost:8000
```

## Note
- Replace `assets/glow.mp4` with a real short looping video for best effect.
- Update API endpoint in `app.js` if your backend is hosted elsewhere.
