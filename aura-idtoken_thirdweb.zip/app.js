document.getElementById('statusBtn').addEventListener('click', async ()=>{
  const el = document.getElementById('status');
  el.textContent = 'Checking API...';
  try{
    const res = await fetch('https://aura-idtoken.duckdns.org/api/status');
    const j = await res.json();
    el.innerHTML = 'API status: <span class="dot online"></span> ' + (j.message || 'online');
  }catch(e){
    el.innerHTML = 'API status: <span class="dot offline"></span> offline';
  }
});

document.getElementById('exploreBtn').addEventListener('click', ()=>{
  window.open('https://github.com/Kamil1230xd/aura-idtoken','_blank');
});
